<?php

namespace Facade\Ignition\Context;

use Facade\FlareClient\Context\ConsoleContext;

class LaravelConsoleContext extends ConsoleContext
{
}
